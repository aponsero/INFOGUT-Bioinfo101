# Quality control example: Bash script vs Nextflow pipeline

Example files for the INFOGUT self-study course, Reproducible research module (Part 3: Workflows with Nextflow).

The same analysis is written twice: FastQC on every sample, then one MultiQC report combining all of them.

## Contents

| File | What it is |
|---|---|
| `environment.yml` | Conda environment with FastQC and MultiQC |
| `samplesheet.csv` | The list of samples (one row per sample; leave `fastq_2` empty for single-end data) |
| `bash_qc.sh` | Version 1: a Bash script |
| `main.nf` | Version 2: a Nextflow pipeline |
| `data/` | Small test FASTQ files (2,500 reads each) |

## Requirements

A Linux or macOS computer with:

- Conda (Miniforge is recommended: https://github.com/conda-forge/miniforge)
- Nextflow (see https://www.nextflow.io/docs/latest/install.html), which needs Java 17 or later

## Run the Bash version

```
conda env create -f environment.yml
conda activate qc
bash bash_qc.sh
```

The report is written to `manual_results/multiqc/multiqc_report.html`.

## Run the Nextflow version

```
nextflow run main.nf --samplesheet samplesheet.csv -with-conda environment.yml
```

The report is written to `results/multiqc/multiqc_report.html`.

## Try -resume

1. Add a fourth sample at the end of `samplesheet.csv` (its files are already in `data/`):

   ```
   S4,data/2a_S115_L001_R1_001.fastq.gz,data/2a_S115_L001_R2_001.fastq.gz
   ```

2. Run the pipeline again, adding `-resume`:

   ```
   nextflow run main.nf --samplesheet samplesheet.csv -with-conda environment.yml -resume
   ```

Only the new sample, and MultiQC, are run again; the other samples are taken from the cache.

## Test data

The FASTQ files are 16S rRNA amplicon test data from the nf-core test-datasets repository (branch `ampliseq`), https://github.com/nf-core/test-datasets, shared under the MIT licence (see `data/LICENSE_nf-core_test-datasets.txt`).
