# Exploring a targeted organic-acid dataset
# INFOGUT self-study course, Metabolomics data module (Part 2)
#
# Data: teaching subset of Garcia-Gutierrez et al. (2026), Food Research
# International 242, 120207. https://doi.org/10.1016/j.foodres.2026.120207
#
# How to run: open this script in RStudio, set the working directory to the
# folder that contains this script and the data/ folder
# (Session > Set Working Directory > To Source File Location),
# then run the script section by section.

# If needed, install the tidyverse once (this needs an internet connection):
# install.packages("tidyverse")

library(tidyverse)


# 1. Import and inspect the data ----------------------------------------------

data_file <- "data/acids.csv"

acids <- read_csv(data_file, show_col_types = FALSE)

# Look at the table: one row per sample, one column per acid (in micrograms/mL)
acids
glimpse(acids)

# How many samples per condition?
acids |>
  count(product)


# 2. Convert concentrations from micrograms/mL to mM --------------------------

# micrograms/mL is the same as mg/L, so dividing by the molecular weight
# (g/mol) gives mmol/L, that is mM.
acids <- acids |>
  mutate(
    formic    = formic / 46.03,
    acetic    = acetic / 60.05,
    propionic = propionic / 74.08,
    lactic    = lactic / 90.08,
    butyric   = butyric / 88.11,
    citric    = citric / 192.12
  )


# 3. Give the conditions clearer names ----------------------------------------

# In the CSV, A is fermentate 1 (Ferm1) and B is fermentate 4 (Ferm4).
acids <- acids |>
  mutate(
    product = case_when(
      product == "A" ~ "Ferm1",
      product == "B" ~ "Ferm4",
      .default = product
    ),
    product = factor(product, levels = c("Control", "Ferm1", "Ferm4"))
  ) |>
  arrange(product, sample)

acids

# Labels used on the plots below ("\n" starts a new line)
product_labels <- c(
  "Control" = "Unfed T24\ncontrol",
  "Ferm1"   = "Ferm1\nModerate protein\nHigher lactose",
  "Ferm4"   = "Ferm4\nHigh protein\nLow lactose"
)


# 4. Wide and long formats ----------------------------------------------------

# Long format: one row per sample and acid
acids_long <- acids |>
  pivot_longer(
    cols = formic:citric,
    names_to = "acid",
    values_to = "value"
  )

acids_long

# Separate the sample information from the measurements
sample_metadata <- acids |>
  select(sample, product, replicate)

measurement_matrix <- acids |>
  select(sample, formic:citric) |>
  column_to_rownames("sample") |>
  as.matrix()

dim(measurement_matrix)  # 6 samples x 6 organic acids


# 5. Check for missing measurements -------------------------------------------

acids_long |>
  group_by(acid) |>
  summarise(
    n_expected = n(),
    n_observed = sum(!is.na(value)),
    n_missing  = sum(is.na(value))
  )


# 6. Plot the organic-acid profiles -------------------------------------------

condition_colours <- c(
  "Control" = "#6C7A89",
  "Ferm1"   = "#00A6A6",
  "Ferm4"   = "#EF8354"
)

acids_long |>
  filter(!is.na(value)) |>
  ggplot(aes(x = product, y = value, colour = product)) +
  # one point per measurement, slightly spread so the points do not overlap
  geom_point(size = 3.5, position = position_jitter(width = 0.05, height = 0, seed = 42)) +
  # a horizontal bar at the mean of each condition (not a confidence interval)
  stat_summary(fun = mean, geom = "crossbar", width = 0.34, colour = "#172A3A") +
  # one panel per acid, each with its own y-axis scale
  facet_wrap(~ acid, scales = "free_y", nrow = 2) +
  scale_x_discrete(labels = product_labels) +
  scale_colour_manual(values = condition_colours) +
  labs(x = NULL, y = "Concentration (mM)") +
  theme_bw(base_size = 13) +
  theme(legend.position = "none")


# 7. Duplicate gaps versus the gap between fermentates ------------------------

# Mean and duplicate gap (difference between R1 and R2) for each condition and acid.
# This assumes two measurements per condition, which is the case in this dataset.
acid_summary <- acids_long |>
  group_by(product, acid) |>
  summarise(
    n_observed    = sum(!is.na(value)),
    mean_value    = mean(value, na.rm = TRUE),
    duplicate_gap = max(value, na.rm = TRUE) - min(value, na.rm = TRUE),
    .groups = "drop"
  )

# Absolute difference between the Ferm1 and Ferm4 means, for each acid
fermentate_gaps <- acid_summary |>
  filter(product %in% c("Ferm1", "Ferm4")) |>
  select(acid, product, mean_value) |>
  pivot_wider(names_from = product, values_from = mean_value) |>
  mutate(between_gap = abs(Ferm4 - Ferm1))

# Put both gaps in one table
gap_comparison <- acid_summary |>
  left_join(fermentate_gaps |> select(acid, between_gap), by = "acid")

gap_comparison

# Plot: points are duplicate gaps, the dashed line is the between-fermentate gap
gap_comparison |>
  ggplot(aes(x = product, y = duplicate_gap, colour = product)) +
  geom_hline(
    data = fermentate_gaps,
    aes(yintercept = between_gap),
    linetype = "dashed",
    colour = "#172A3A"
  ) +
  geom_point(size = 3) +
  facet_wrap(~ acid, scales = "free_y", nrow = 2) +
  scale_x_discrete(labels = product_labels) +
  scale_colour_manual(values = condition_colours) +
  labs(x = NULL, y = "Absolute gap (mM)") +
  theme_bw(base_size = 13) +
  theme(legend.position = "none")
