# Metabolomics demo: exploring a targeted organic-acid dataset

Teaching dataset for the INFOGUT self-study course, Metabolomics data module (Part 2: Hands-on demo in R).

## Contents

| File | Contents | Layout |
|---|---|---|
| `organic_acids_demo.R` | The R code used on the course page | Run section by section in RStudio |
| `data/acids.csv` | Six organic acids (formic, acetic, propionic, lactic, butyric, citric), in micrograms/mL | 6 sample rows; identifiers and acids in columns |
| `data/insulin.csv` | Insulin measurements from three experiments | 18 rows; each sample occurs in experiments 1, 2 and 3 |
| `data/abundance.csv` | Microbiome abundance values for 190 species | Species in rows; the six samples in columns |
| `data/taxonomy.csv` | Taxonomic assignments for the 190 species | Species, kingdom, phylum, class, order, family and genus |

The demo uses `acids.csv`. The other files are there if you want to go further and connect the data layers; they are not needed to run the demo.

## How to run the demo

1. Unzip this folder and keep the files in the same arrangement (the script reads `data/acids.csv`).
2. Open `organic_acids_demo.R` in RStudio.
3. Set the working directory to this folder: Session > Set Working Directory > To Source File Location.
4. If needed, install the tidyverse once: `install.packages("tidyverse")`.
5. Run the script section by section.

## Samples

Six samples from an in vitro colon model (microMatrix), 24 h incubation with a pooled faecal inoculum:

| Sample IDs | Condition in the CSV | Condition |
|---|---|---|
| Control_R1, Control_R2 | Control | Unfed control at 24 h |
| A_R1, A_R2 | A | Fermentate 1 (Ferm1) at 5% |
| B_R1, B_R2 | B | Fermentate 4 (Ferm4) at 5% |

R1 and R2 are duplicate fermentation wells prepared from the same pooled faecal inoculum, not independent donors.

## Source

Teaching subset of the data from:

Garcia-Gutierrez et al. (2026). A microbiota-informed pipeline for in vitro characterisation of insulinotropic properties of dairy fermentates using static EndoC-βH1 and dynamic microfluidic models. Food Research International, 242, 120207. https://doi.org/10.1016/j.foodres.2026.120207

The article is open access under a CC BY 4.0 licence. Please cite it if you reuse these data.
